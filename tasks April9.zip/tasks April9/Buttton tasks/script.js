// 1. Change Text
function changeText() {
    document.getElementById("text").innerText = "Text Changed!";
}

// 2. Change Background Color
function changeColor() {
    document.body.style.backgroundColor = "lightblue";
}

// 3. Show Input Value
function showInput() {
    let value = document.getElementById("inputBox").value;
    document.getElementById("output").innerText = value;
}