let a = 10;
let b = 5;

console.log(a > b);   // true
console.log(a == b);  // false
console.log(a != b);  // true