// 1. Callback
function processNumber(num, callback) {
    let result = num * 2;
    callback(result);
}

processNumber(5, (res) => console.log("Callback:", res));


// 2. Promise
function checkNumber(num) {
    return new Promise((resolve, reject) => {
        num > 10 ? resolve("Success") : reject("Fail");
    });
}

checkNumber(15)
    .then(res => console.log("Promise:", res))
    .catch(err => console.log("Promise:", err));


// 3 & 4 Async + Error Handling
function getData() {
    return new Promise((resolve, reject) => {
        let error = false;
        error ? reject("Error") : resolve("Data received");
    });
}

async function fetchData() {
    try {
        let res = await getData();
        console.log("Async:", res);
    } catch {
        console.log("Something went wrong");
    }
}

fetchData();


// 5. Fetch API
fetch("https://jsonplaceholder.typicode.com/posts")
    .then(res => res.json())
    .then(data => data.forEach(post => console.log("Title:", post.title)))
    .catch(err => console.log(err));