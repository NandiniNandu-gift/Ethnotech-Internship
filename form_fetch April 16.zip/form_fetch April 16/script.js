function checkResult() {
    return new Promise((resolve, reject) => {

        let ok = true; // change to false to test

        setTimeout(() => {
            if (ok) {
                resolve("Success 🎉");
            } else {
                reject("Error ❌");
            }
        }, 2000);

    });
}

checkResult()
    .then((msg) => {
        console.log(msg);
    })
    .catch((err) => {
        console.log(err);
    });