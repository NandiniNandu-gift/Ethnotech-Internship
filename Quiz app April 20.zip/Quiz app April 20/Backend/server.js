const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Quiz questions
const questions = [
  {
    id: 1,
    question: "What is 2 + 2?",
    options: ["2", "4", "6", "8"],
    answer: "4",
  },
  {
    id: 2,
    question: "Capital of India?",
    options: ["Delhi", "Mumbai", "Chennai", "Kolkata"],
    answer: "Delhi",
  },
];

// API to send questions
app.get("/questions", (req, res) => {
  res.json(questions);
});

// API to calculate score
app.post("/submit", (req, res) => {
  const userAnswers = req.body.answers;
  let score = 0;

  questions.forEach((q, index) => {
    if (q.answer === userAnswers[index]) {
      score++;
    }
  });

  res.json({ score });
});

// start server
app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});