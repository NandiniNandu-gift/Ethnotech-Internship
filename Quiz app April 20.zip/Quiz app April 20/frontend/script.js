let questions = [];
let userAnswers = [];

// Fetch questions from backend
fetch("http://localhost:5000/questions")
  .then(res => res.json())
  .then(data => {
    questions = data;
    displayQuestions();
  });

function displayQuestions() {
  const quizDiv = document.getElementById("quiz");

  questions.forEach((q, index) => {
    let html = `<p>${q.question}</p>`;

    q.options.forEach(option => {
      html += `
        <input type="radio" name="q${index}" value="${option}"
        onchange="saveAnswer(${index}, '${option}')">
        ${option} <br>
      `;
    });

    quizDiv.innerHTML += html;
  });
}

// Save selected answer
function saveAnswer(index, answer) {
  userAnswers[index] = answer;
}

// Submit quiz
function submitQuiz() {
  fetch("http://localhost:5000/submit", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ answers: userAnswers }),
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("result").innerText =
        "Your Score: " + data.score;
    });
}