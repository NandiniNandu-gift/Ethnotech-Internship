class User {
    #password;  // private variable

    setPassword(pass) {
        if (pass.length < 6) {
            console.log("Password too short");
        } else {
            this.#password = pass;
        }
    }

    getPassword() {
        return this.#password;
    }
}

// Usage
const u1 = new User();

u1.setPassword("123");      // invalid
u1.setPassword("123456");   // valid

console.log(u1.getPassword());