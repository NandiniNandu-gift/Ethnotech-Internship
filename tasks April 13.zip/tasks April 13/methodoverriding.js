class Animal {
    eat() {
        console.log("Animal eats food");
    }
}

class Dog extends Animal {
    eat() {
        super.eat(); // calling parent method
        console.log("Dog eats bones");
    }
}

// Usage
const d1 = new Dog();
d1.eat();