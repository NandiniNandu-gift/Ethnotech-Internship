class Laptop {
    #bootSystem() {
        console.log("Booting system...");
    }

    start() {
        this.#bootSystem();   // calling private method
        console.log("Laptop started");
    }
}

// Usage
const lap = new Laptop();
lap.start();