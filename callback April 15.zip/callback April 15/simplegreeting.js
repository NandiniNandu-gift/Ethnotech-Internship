// Task 1: Simple Greeting Callback

function greet(name, callback) {
    console.log("Hello " + name);
    callback();
}

function sayBye() {
    console.log("Goodbye!");
}

// Run
greet("Nandini", sayBye);