// Task 2: Calculator with Callback

function calculate(a, b, callback) {
    let result = a + b;   // you can change to -, *, /
    callback(result);
}

function display(result) {
    console.log("Result is:", result);
}

// Run
calculate(10, 5, display);