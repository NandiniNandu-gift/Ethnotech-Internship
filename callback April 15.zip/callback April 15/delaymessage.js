// Task 3: Delay Message using setTimeout

function showMessage(callback) {
    setTimeout(() => {
        console.log("Message after 3 seconds");
        callback();
    }, 3000);
}

function done() {
    console.log("Task completed");
}

// Run
showMessage(done);